# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from matplotlib import pyplot as plt
import numpy as np
import itertools

total_forms = 61
cost_per_hour = 7.2
total_cost = []
for n_forms in range(4,11):
    items_per_form = total_forms/n_forms
    forms = np.array([items_per_form]*n_forms)
    forms += [1]*(total_forms-sum(forms)) + [0] * (n_forms - (total_forms-sum(forms)))
    combos =  [sum(x) for x in itertools.combinations(forms,2)]  
    cost = sum(combos)/5.0*cost_per_hour*200
    total_cost.append((n_forms,cost))
    n_comparisons = 0
    tmp = [forms*f for f in forms]
    for i in range(len(tmp)-1):
        n_comparisons += sum(tmp[i][i+1:])
    n_comparisons += sum([f*(f-1)/2 for f in forms])